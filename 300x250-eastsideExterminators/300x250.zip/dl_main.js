
//PRELOAD DE IMG
this.addEventListener("DOMContentLoaded", preloadImages, true);

var loadedImages = 0;
//ACA HAY QUE CARGAR LAS IMAGENES QUE SE USEN
var imageArray = new Array("images/logo.png" );

function preloadImages(e) {
    for (var i = 0; i < imageArray.length; i++) {
        var tempImage = new Image();
        tempImage.addEventListener("load", trackProgress, true);
        tempImage.src = imageArray[i];
    }
}

function trackProgress() {
    loadedImages++;
    if (loadedImages == imageArray.length) {
        imagesLoaded();
    }
}

function imagesLoaded() {
    
    document.getElementById('loader-container').style.display = 'none';
    document.getElementById('banner_content').style.display = 'block';
    

    initHandlers();
    initAnimations();

}

/* PARA DETECTAR SI ES IOs */
var is_Mac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
var iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;

if (is_Mac == true || iOS == true) {
     
}



/* PARA DETECTAR SI ES IE */
if(navigator.userAgent.indexOf('MSIE')!==-1
|| navigator.appVersion.indexOf('Trident/') > 0){

  alert("IE");
  
}


// VARIABLES GLOBALES
var multitimeline = new TimelineMax({paused:false, repeat: 0});
    multitimeline.timeScale( 1 );  
    multitimeline
    .add(fr1(), 0)


    ;


function fr1(){
      var tl_ = new TimelineMax({repeat: 0});  
          tl_.timeScale( 1 );  
          tl_
          .staggerFrom("[id*='txt-1']", 0.7, {autoAlpha: 0, ease:Power2.easeInOut}, 0.2,  0)
          .staggerFrom("[id*='txt-1']", 0.7, {y: 20, ease:Power2.easeInOut}, 0.2,  0)

          .from("#filter_horizontal", 0.7, {x: 200, ease:Power2.easeOut}, 1)
          .from("#filter_vertical", 1, {x: 200, ease:Power2.easeOut}, 1)

          .staggerFrom("[id*='txt-2']", 0.7, {autoAlpha: 0, ease:Power2.easeInOut}, 0.2,  1.5)
          .staggerFrom("[id*='txt-2']", 0.7, {y: 20, ease:Power2.easeInOut}, 0.2,  1.5)   
          
          .from("#extra, #registerNow", 0.7, {y: -100, ease:Power2.easeOut}, 2.2)          

          ;
return tl_  
}




function initAnimations(){
    multitimeline.timeScale(1); 
}


//HANDLERS
function initHandlers() {

  var clicktag = document.getElementById('clickTag');
/*
    clicktag.addEventListener('mouseup', function(event) {                 
    window.open(window.clickTag,'_blank'); 
  })
*/

function getParameterByName(name) {
  var match = RegExp( "[?&]" + name +  "=([^&]*)" ).exec(window.location.search);
  return match && decodeURIComponent(match[ 1 ].replace(/\+/g,  " " ))
  }       
      
      clicktag.addEventListener('mouseup', function(event) {                
         window.open(getParameterByName( "clickTag" ),  "_blank" )      
      })  
        
          
   


  


  clicktag.addEventListener('mouseenter', function (e) {
      a.enter();
  });

  clicktag.addEventListener('mouseleave', function (e) {
      a.leave();
  });


  var a = {
    enter: function () {
      console.log('enter');
      var tl = new TimelineMax({
        defaults: { duration: 0.5, ease: 'easeInOut' },
      });
      tl
        .to("#registerNow", 0.2, {scale: 1.1, rotation: 0, ease:Power2.easeOut}, 0)
    },
    leave: function () {
      console.log('leave');
      var tl = new TimelineMax({
        defaults: { duration: 0.5, ease: 'easeInOut' },
      });
      tl
        .to("#registerNow", 0.2, {scale: 1, rotation: 0.01, ease:Power2.easeOut}, 0)

    },
  };

}

